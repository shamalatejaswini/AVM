USE SCHEMA EMP_RAW;
create table employee (
	fname varchar(30),
	minit char(1),
	lname varchar(30),
	ssn char(9),
	bdate date,
	address varchar(30),
	sex char(1),
	salary decimal(10,2),
	super_ssn char(9),
	dno int

);

create table department(
	dname varchar(30),
	dnumber smallint,
	mgr_ssn char(9),
	mgr_start_date date
);

create table dept_locations(
	dnumber smallint,
	dlocation varchar(20)
);

create table project(
	pname varchar(30),
	pnumber smallint,
	plocation varchar(30),
	dnum smallint
);

create table works_on(
	essn char(9),
	pno smallint,
	hours decimal(4,2)
);

create table dependent(
	essn char(9),
	dependent_name varchar(30),
	sex char(1),
	bdate date,
	relationship varchar(20)

);


USE SCHEMA EMP_PROC;

create table emp_sal_greater_mngr(
essn char(9),
salary decimal(10,2),
Super_snn char(9),
Super_salary decimal(10,2)
);


create table emp_project_dept(

essn char(9),
pname varchar(30),
emp_dept_name varchar(30),
proj_dept_name varchar(30)

);

create table emp_dept_least(
dept_name varchar(30),
dept_no smallint,
no_of_emp smallint
);

create table emp_tot_hrs_spent(
essn char(9),
dependent_name varchar(30),
pno smallint,
total_hours_spent smallint
);


create table emp_full_details(
essn char(9),
fname varchar(30),
minit char(1),
lname varchar(30),
bdate date,
address varchar(30),
sex char(1),
salary decimal(10,2),
super_ssn char(9),
dno int,
dname char(30),
dlocation char(30),
pname char(30),
pnumber smallint,
plocation char(30),
total_hours DECIMAL(10, 2),
dependent_name char(30),
dependent_sex char(30),
dependent_relation char(30)
);




