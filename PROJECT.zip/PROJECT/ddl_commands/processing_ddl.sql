INSERT INTO EMP_PROC.emp_sal_greater_mngr
SELECT 
    e.ssn as ssn,
    e.salary,
    m.ssn as Super_ssn,
    m.salary as Super_salary
FROM
    EMP_RAW.EMPLOYEE e
JOIN
    EMP_RAW.EMPLOYEE m ON e.Super_ssn=m.ssn
WHERE e.salary > m.salary;


INSERT INTO EMP_PROC.emp_project_dept
SELECT 
    e.ssn AS essn, 
    p.pname, 
    d1.dname AS emp_dept_name, 
    d2.dname AS proj_dept_name
FROM 
    EMP_RAW.EMPLOYEE e
JOIN 
    EMP_RAW.WORKS_ON w ON e.ssn = w.essn
JOIN 
    EMP_RAW.PROJECT p ON w.pno = p.pnumber
JOIN 
    EMP_RAW.DEPARTMENT d1 ON e.dno = d1.dnumber
JOIN 
    EMP_RAW.DEPARTMENT d2 ON p.dnum = d2.dnumber
WHERE 
    e.dno <> p.dnum;


INSERT INTO EMP_PROC.emp_dept_least
SELECT 
    d.dname as dept_name,
    d.dnumber as dept_no, 
    count(e.ssn) as no_of_emp 
FROM 
    EMP_RAW.DEPARTMENT d 
JOIN 
    EMP_RAW.EMPLOYEE e ON d.dnumber=e.dno
GROUP BY 
    d.dname,d.dnumber
ORDER BY
    no_of_emp
LIMIT 1;


INSERT INTO EMP_PROC.emp_tot_hrs_spent
SELECT
    e.ssn AS essn,
    d.dependent_name AS dependent_name,
    w.pno,
    SUM(w.hours) AS total_hours_spent
FROM 
    EMP_RAW.EMPLOYEE e
JOIN 
    EMP_RAW.DEPENDENT d ON e.ssn=d.essn 

JOIN 
    EMP_RAW.WORKS_ON w ON e.ssn=w.essn
GROUP BY
    ssn,d.dependent_name,w.pno;


INSERT INTO EMP_PROC.emp_full_details
SELECT 
    e.ssn AS essn, 
    e.fname, 
    e.minit, 
    e.lname, 
    e.bdate, 
    e.address, 
    e.sex, 
    e.salary, 
    e.super_ssn, 
    e.dno, 
    d.dname, 
    dl.dlocation, 
    p.pname, 
    p.pnumber, 
    p.plocation, 
    w.total_hours, 
    dep.dependent_name, 
    dep.sex AS dependent_sex, 
    dep.relationship AS dependent_relation
FROM 
    EMP_RAW.employee e
LEFT JOIN 
    EMP_RAW.department d ON e.dno = d.dnumber
LEFT JOIN 
    EMP_RAW.dept_locations dl ON e.dno = dl.dnumber
LEFT JOIN 
    (SELECT essn, pno, SUM(hours) AS total_hours FROM EMP_RAW.works_on GROUP BY essn, pno) w ON e.ssn = w.essn
LEFT JOIN 
    EMP_RAW.project p ON w.pno = p.pnumber
LEFT JOIN 
    EMP_RAW.dependent dep ON e.ssn = dep.essn;

